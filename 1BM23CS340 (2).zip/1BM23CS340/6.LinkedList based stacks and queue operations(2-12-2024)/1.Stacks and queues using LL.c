#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node* next;
};

struct Node* head = NULL;

void insertAtEnd(int data) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    struct Node* temp;
    newNode->data = data;
    newNode->next = NULL;
    if (head == NULL) {
        head = newNode;
    } else {
        temp = head;
        while (temp->next != NULL) {
            temp = temp->next;
        }
        temp->next = newNode;
    }
}

void sortList() {
    struct Node* i;
    struct Node* j;
    int temp;
    for (i = head; i != NULL; i = i->next) {
        for (j = i->next; j != NULL; j = j->next) {
            if (i->data > j->data) {
                temp = i->data;
                i->data = j->data;
                j->data = temp;
            }
        }
    }
    printf("Linked list sorted.\n");
}

void reverseList() {
    struct Node *prev = NULL, *current = head, *next = NULL;
    while (current != NULL) {
        next = current->next;
        current->next = prev;
        prev = current;
        current = next;
    }
    head = prev;
    printf("Linked list reversed.\n");
}

void concatenateLists(struct Node* head1, struct Node* head2) {
    if (head1 == NULL) {
        head = head2;
        return;
    }
    struct Node* temp = head1;
    while (temp->next != NULL) {
        temp = temp->next;
    }
    temp->next = head2;
    head = head1;
    printf("Linked lists concatenated.\n");
}

void displayList() {
    struct Node* temp = head;
    if (temp == NULL) {
        printf("The list is empty.\n");
    } else {
        printf("Linked list contents: ");
        while (temp != NULL) {
            printf("%d -> ", temp->data);
            temp = temp->next;
        }
        printf("NULL\n");
    }
}

int main() {
    int choice, data, n, i;
    struct Node *list1 = NULL, *list2 = NULL;

    while (1) {
        printf("\nSingly Linked List Operations:\n");
        printf("1. Insert at End\n2. Sort List\n3. Reverse List\n4. Concatenate Two Lists\n5. Display List\n6. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter data to insert at end: ");
                scanf("%d", &data);
                insertAtEnd(data);
                break;
            case 2:
                sortList();
                break;
            case 3:
                reverseList();
                break;
            case 4:
                printf("Enter number of nodes for first list: ");
                scanf("%d", &n);
                for (i = 0; i < n; i++) {
                    printf("Enter data for node %d of list1: ", i + 1);
                    scanf("%d", &data);
                    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
                    newNode->data = data;
                    newNode->next = list1;
                    list1 = newNode;
                }
                printf("Enter number of nodes for second list: ");
                scanf("%d", &n);
                for (i = 0; i < n; i++) {
                    printf("Enter data for node %d of list2: ", i + 1);
                    scanf("%d", &data);
                    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
                    newNode->data = data;
                    newNode->next = list2;
                    list2 = newNode;
                }
                concatenateLists(list1, list2);
                break;
            case 5:
                displayList();
                break;
            case 6:
                return 0;
            default:
                printf("Invalid choice!\n");
        }
    }
}
