#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node* prev;
    struct Node* next;
};

struct DoublyLinkedList {
    struct Node* head;
};

void createList(struct DoublyLinkedList* dll, int data) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = data;
    newNode->prev = newNode->next = NULL;

    if (dll->head == NULL) {
        dll->head = newNode;
    } else {
        struct Node* temp = dll->head;
        while (temp->next != NULL) {
            temp = temp->next;
        }
        temp->next = newNode;
        newNode->prev = temp;
    }
}

void insertLeft(struct DoublyLinkedList* dll, int newData, int existingData) {
    struct Node* temp = dll->head;
    while (temp != NULL && temp->data != existingData) {
        temp = temp->next;
    }

    if (temp != NULL) {
        struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
        newNode->data = newData;
        newNode->next = temp;
        newNode->prev = temp->prev;

        if (temp->prev != NULL) {
            temp->prev->next = newNode;
        } else {
            dll->head = newNode;
        }
        temp->prev = newNode;
    } else {
        printf("Node with data %d not found.\n", existingData);
    }
}

void deleteNode(struct DoublyLinkedList* dll, int value) {
    struct Node* temp = dll->head;

    while (temp != NULL && temp->data != value) {
        temp = temp->next;
    }

    if (temp == NULL) {
        printf("Node with value %d not found.\n", value);
        return;
    }

    if (temp->prev != NULL) {
        temp->prev->next = temp->next;
    } else {
        dll->head = temp->next;
    }

    if (temp->next != NULL) {
        temp->next->prev = temp->prev;
    }

    printf("Node with value %d deleted.\n", value);
}

void display(struct DoublyLinkedList* dll) {
    if (dll->head == NULL) {
        printf("List is empty.\n");
        return;
    }

    struct Node* temp = dll->head;
    while (temp != NULL) {
        printf("%d ", temp->data);
        temp = temp->next;
    }
    printf("\n");
}

int main() {
    struct DoublyLinkedList dll;
    dll.head = NULL;

    createList(&dll, 10);
    createList(&dll, 20);
    createList(&dll, 30);
    createList(&dll, 40);

    printf("Original List:\n");
    display(&dll);

    insertLeft(&dll, 25, 30);
    printf("List after inserting 25 to the left of 30:\n");
    display(&dll);

    deleteNode(&dll, 20);
    printf("List after deleting node with value 20:\n");
    display(&dll);

    deleteNode(&dll, 50);
    return 0;
}
